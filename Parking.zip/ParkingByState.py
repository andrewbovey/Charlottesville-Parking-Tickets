import matplotlib.pyplot as plt

#this class takes in a dataframe and provides several functiions to ease code writting
class State:
    
    def __init__(self, frame):
        self.frame = frame
    
    #creates a string year column for an incoming data frame with a specified date column     
    def yearCol(self, dateCol):
        self.frame.loc[:,'Year'] = self.frame[dateCol].dt.strftime('%Y')
    
    #renames columns to whatever values are given as arguments     
    def rename(self, *args):
       colList = []
       for col in args:
           colList.append(col)
       self.frame.columns = colList
    
    #cleans bad years out of the year column, returns this as a new dataframe
    def cleanYears(self):
        new = self.frame.loc[self.frame['Year'].isin(['1999', '2088', '2097', '2208']) == False]
        return new
    
    #returns a dataframe of values that have been grouped according to the parameters 
    #then summed
    def summary(self, cols):
       new = self.frame.groupby(cols).size().reset_index()
       return new
    
    #does the same as summary except specifically for two columns where one is grouped and value is 
    #summed according to the second value
    def summarySpecific(self, Col1, Col2):
       new = self.frame.groupby([Col1])[Col2].size().reset_index()
       return new
   
    #removes a row from the data frame according to the value for a select value  
    def removeState(self, state):
        self.frame = self.frame.drop(self.frame[self.frame.State == state].index)
    
    #generates a new column for the frame with location values based on the existing state value    
    def location(self):
        pacific =["WA", "OR", "HI", "AK", "CA"]
        mountainWest =["AZ", "NM", "CO", "ID", "MT", "NV", "UT", "WY"] 
        midWest = ["MI", "OH", "IN", "WI", "IL", "MO", "IA", "MN", "ND", "SD", "NE", "KS"] 
        southAtlantic = ["DE", "FL", "GA", "MD", "NC", "SC", "DC", "WV"] 
        southCentral = ["AL", "AR", "KY", "LA", "MS", "OK", "TN", "TX"] 
        northEast = ["CT", "DE", "ME", "MA", "NH", "NJ", "NY", "PA", "RI", "VT"] 
        
        self.frame.loc[:, 'Location'] = "Other" 
        self.frame.loc[self.frame.State.isin(pacific), 'Location'] = "Pacific"
        self.frame.loc[self.frame.State.isin(mountainWest), 'Location'] = "Mountain West"
        self.frame.loc[self.frame.State.isin(midWest), 'Location'] = "Mid West"
        self.frame.loc[self.frame.State.isin(southAtlantic), 'Location'] = "South Atlantic"
        self.frame.loc[self.frame.State.isin(southCentral), 'Location'] = "South Central"
        self.frame.loc[self.frame.State.isin(northEast), 'Location'] = "Northeast"
     
    #reduces the states present to the specifically selected ones
    def reduceStates(self, states):
        new = self.frame.loc[self.frame['State'].isin(states)]
        return new
    
    #uses matplotlib to generate a basic line graph for year and state columns of a select data frame
    def basicGraph(self, title, y, x, outfile):
        plt.figure(figsize=(10,5))
        plt.plot(self.frame['Year'], self.frame['State'], 'bo-')
        plt.title(title)
        plt.ylabel(y)
        plt.xlabel(x)
        plt.savefig(outfile)
    
    #uses matplotlib to generate a basic bar graph for location and state columns of a select data frame 
    def barGraph(self, title, y, x, outfile):
        plt.figure(figsize=(10,5))
        plt.bar(self.frame['Location'], self.frame['State'])
        plt.title(title)
        plt.ylabel(y)
        plt.xlabel(x)
        plt.savefig(outfile)
    
    #pivots the data frame to make the state values the columns and the total tickets the values
    #then uses matplotlib to plant these values with a legend 
    def advancedGraph(self, title, y, x, outfile, legLab, legSize):
        top_print = self.frame.pivot(index='Year', columns='State', values='Total Tickets')
        plt.figure(figsize=(10,5))
        plt.plot(top_print)
        plt.legend(legLab,
           loc='upper right',  prop={'size': legSize})
        plt.title(title)
        plt.ylabel(y)
        plt.xlabel(x)
        plt.savefig(outfile)
    

