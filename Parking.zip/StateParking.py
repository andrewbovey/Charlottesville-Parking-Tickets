import pandas as pd
from ParkingByState import *

df = pd.read_csv('Parking_Tickets.csv')
state = State(df)
state.frame['Date'] = df.DateIssued.str[:10]
state.frame['Date'] = pd.to_datetime(df['Date'], infer_datetime_format = True, errors='coerce')
state.yearCol('Date')

state.frame = state.frame.drop(columns=['RecordID','TicketNumber','DateIssued', 'StreetName','StreetNumber','TimeIssued','ViolationDescription', 'Date', 
                      'WaiverRequestDate','WaiverGrantedDate','AppealDate','AppealGrantedDate','AppealStatus','Location','LicensePlateAnon'])
state.rename('State', 'Year')

x = state.cleanYears()
state_counts = x.groupby(['Year', 'State']).size()            #indexed by year and state, reduced to series 
state_counts.sum()
state.removeState('VA')                                                   #drops VA from frame
state.removeState('  ')                                                   #drops blanks from frame 
clean_states = State(state.cleanYears())                                  #drops bad years
clean_states.location()                                                   #adds location in the united states
 
x = 52904/435304 #% of out of state tickets
#aggregates total tickets by state
c = clean_states.summary('State')
c.columns = ['State', 'Year']
c = c.sort_values(by=['Year'], ascending = False).reset_index().drop(columns = ['index']) #List of all states by order of tickets
c.iloc[0:10,0:2]                     

#Indexes by year and by state and adds the total number of tickets meeting those conditions
#while maintaining year and state columns                                                   
new_clean = State(clean_states.summary(['Year', 'State']))
new_clean.rename('Year', 'State', 'Total Tickets')                          
top_five = State(new_clean.reduceStates(['MD', 'NC', 'PA', 'FL', 'NY'])) #5 States with most tickets

#Sorts by us location and makes a new frame with totals for each place. Also orders from largest to smallest
location= State(clean_states.summarySpecific('Location', 'State'))
location = State(location.frame.sort_values(by=['State'], ascending=False))
#this = clean_states.frame.groupby(['Location'])['State'].size().reset_index()

by_year = State(clean_states.summarySpecific('Year', 'State'))                                   #finds total number of out of state tickets each year
percent_year =  pd.concat([by_year.frame['State'].pct_change(), by_year.frame['Year']], axis=1)  #finds percent change each year 
percent_year = State(percent_year.drop([0]))                                                     #drops 2000
 
location.barGraph('Location of Each Non-Virginia License Plate', 'Total Tickets', 'Location', 'location.png')
percent_year.basicGraph('Percent Change Each Year', 'Percent Change', 'Year', 'percentbyyear.png')
by_year.basicGraph('Out of State Tickets Each Year', 'Total Tickets', 'Year', 'totalperstateperyear.png')
top_five.advancedGraph('Total Tickets for 5 Highest Frequency States', 'Total Tickets', 'Year'
                       , 'topfivestates.png', ('FL', 'MD', 'NC', 'NY', 'PA'), 10)

