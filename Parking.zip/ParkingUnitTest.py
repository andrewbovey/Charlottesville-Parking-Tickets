import pandas as pd
import unittest
from ParkingByState import *

class FrameTests(unittest.TestCase):
    
    #testing if rename is giving the columns proper names by comparing the renamed columns
    #with the expected values
    def test_is_rename_giving_correct_name(self):
        df = pd.read_csv('TestData.csv')
        data = State(df)
        data.rename('State', 'Year', 'Next')
        
        self.assertEqual(data.frame.columns[1], 'Year')
    
    #tests if clean years is removing the right rows by comparing number of rows to a csv containing
    #bad years before and after cleaning
    def test_is_cleanYears_cleaning_correct_row(self):
        df = pd.read_csv('TestData.csv')
        data = State(df)
        new = data.cleanYears()

        self.assertEqual(new.shape[0], 10)  
     
    #tests if the summary function is counting correctly by comparing the values when a data frame
    #containing 3 cases of year being 2008 is summed by year
    def test_summary_is_aggregating_properly(self):
        df = pd.read_csv('TestData2.csv')
        data = State(df)
        new = data.summary(['Year'])    
        
        self.assertEqual(new[0][new['Year'] == 2008].iloc[0], 3)
     
    #tests similar to the original summary function as the only difference between the two is indexing
    #so the same test is used albeit with a different value to be compared
    def test_summarySpecific_is_aggregating_properly(self):
        df = pd.read_csv('TestData2.csv')
        data = State(df)
        new = data.summarySpecific('Year', 'State')

        self.assertEqual(new['State'][new['Year'] == 2004].iloc[0], 2)    
    
    #tests to make sure the states are being reduced to the select states by comparing size of a data frame
    #with a number of states after reducing to only two
    def test_is_reduceStates_reducing(self):
        df = pd.read_csv('TestData3.csv')
        data = State(df)        
        new = data.reduceStates(['DC', 'NJ'])
        
        self.assertEqual(new.shape[0], 5)
    
    #tests if the states are being removed by comparing expected length after removal with the length of
    #the value of the length of the column    
    def test_is_removeState_removing(self):
        df = pd.read_csv('TestData3.csv')
        data = State(df) 
        data.removeState('NJ')
        
        self.assertEqual(data.frame.shape[0], 9)
        
    #tests if a year column is being made by seeing if the column is not none after it is called
    #on a small data frame that includes dates that are formatted properly
    def test_yearCol_forming_new_column(self):
        df = pd.read_csv('TestData4.csv')
        data = State(df)  
        data.frame['Date'] = pd.to_datetime(data.frame['Date'], infer_datetime_format = True, errors='coerce')
        data.yearCol('Date')
        
        self.assertIsNotNone(data.frame['Year'])
    
    #tests if the year columns has the right dates by comparing the expected year to the actual for a row
    #in the data frame    
    def test_yearCol_has_right_years(self):
        df = pd.read_csv('TestData4.csv')
        data = State(df)  
        data.frame['Date'] = pd.to_datetime(data.frame['Date'], infer_datetime_format = True, errors='coerce')
        data.yearCol('Date')
        
        self.assertEqual(data.frame['Year'][1], '2013')
        
if __name__ == '__main__':
    unittest.main()   
